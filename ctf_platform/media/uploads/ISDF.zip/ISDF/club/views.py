from django.shortcuts import render
from .models import Event, Member
# Create your views here.

def base(request):
    return render(request, 'club/base.html')

def contact(request):
    return render(request, 'club/contact.html')

def events(request):
    events = Event.objects.all()
    return render(request, 'club/events.html', {'events': events})

def members(request):
    members = Member.objects.all()
    return render(request, 'club/members.html', {'members': members})

def home(request):
    members = Member.objects.all()
    return render(request, 'club/home.html', {'home': home})
    
