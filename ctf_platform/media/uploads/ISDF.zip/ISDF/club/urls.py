from django.urls import path, include
from . import views



urlpatterns = [
    path('', views.base, name='base'),
    path('contact/', views.contact, name='contact'),
    path('events/', views.events, name='events'),
    path('members/', views.members, name='members'),
    path('home/', views.home, name='home'),
]
