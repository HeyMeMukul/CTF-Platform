document.addEventListener("DOMContentLoaded", () => {
  const faces = {
    front: document.querySelector(".front"),
    right: document.querySelector(".right"),
    back: document.querySelector(".back"),
    left: document.querySelector(".left"),
  };

  const urls = {
    front: "/home",
    right: "/events",
    back: "/members",
    left: "/contact",
  };

  // Load content for each face from the specified URLs
  async function loadFaceContent() {
    await Promise.all(
      Object.entries(urls).map(async ([face, url]) => {
        if (url) {
          try {
            const response = await fetch(url);
            const content = await response.text();
            faces[face].innerHTML = content;
          } catch (err) {
            console.error(`Failed to load ${face} content:`, err);
          }
        }
      })
    );
  }

  loadFaceContent(); // Load content for all faces once

  const navLinks = document.querySelectorAll(".nav-link");
  const cube = document.querySelector(".cube");

  // Initial rotation state
  let rotationY = 0;
  let rotationX = 0;

  // Setup navigation to rotate the cube without reloading content
  navLinks.forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault();

      const face = link.getAttribute("data-face");
      if (!face) {
        console.error("Data-face attribute not found on link.");
        return;
      }

      // Adjust cube rotation based on clicked face
      switch (face) {
        case "front":
          rotationY = 0;
          rotationX = 0;
          break;
        case "right":
          rotationY = -90;
          rotationX = 0;
          break;
        case "back":
          rotationY = -180;
          rotationX = 0;
          break;
        case "left":
          rotationY = 90;
          rotationX = 0;
          break;
        default:
          console.error("Invalid face value.");
          return;
      }

      // Apply rotation to cube
      cube.style.transform = `rotateY(${rotationY}deg) rotateX(${rotationX}deg)`;
      window.history.pushState({}, "", link.href);
    });
  });

  // Smooth rotation transition
  cube.style.transition = "transform 0.6s ease";

  // Dragging functionality for cube rotation
  let isDragging = false;
  let startX, startY;

  document.querySelector(".container").addEventListener("mousedown", (e) => {
    isDragging = true;
    startX = e.pageX;
    startY = e.pageY;
    cube.style.transition = "transform 0.1s ease";
  });

  document.addEventListener("mouseup", () => {
    isDragging = false;
    cube.style.transition = ""; // Remove transition after drag
  });

  document.addEventListener("mousemove", (e) => {
    if (!isDragging) return;

    const deltaX = e.pageX - startX;
    const deltaY = e.pageY - startY;

    // Update rotation values based on mouse movement
    rotationY += deltaX * 0.2;
    rotationX -= deltaY * 0.2;

    // Limit X rotation to avoid excessive flipping
    rotationX = Math.max(-90, Math.min(90, rotationX));

    cube.style.transform = `rotateX(${rotationX}deg) rotateY(${rotationY}deg)`;

    // Reset start coordinates for smooth dragging
    startX = e.pageX;
    startY = e.pageY;
  });

  // Handle browser back/forward navigation
  window.addEventListener("popstate", () => {
    // Optionally update cube rotation or reload content if necessary
  });
});
